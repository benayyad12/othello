int othellier[100];       /*l'echiquier d'othello*/
int ordre_cases[60] = {
                        11,18,81,88,14,15,41,51,
                        48,58,84,85,13,16,31,61,
                        38,68,83,86,33,34,35,36,
                        43,53,46,56,63,64,65,66,
                        24,25,42,52,47,57,74,75,
                        23,26,32,62,37,67,73,76,
                        12,17,21,28,71,78,82,87,
                        22,27,72,77
                      };      /*table pour ordonner les cases*/
int othellier_partie[100];
                      
int ncv;                  /*nbre de cases vides sur le jeu*/

int couleur_HPothelloC; /*couleur des pions du programme (blanc ou noir)*/
int side;               /*couleur qui joue*/
int prof_max;           /*profondeur d'analyse maximum*/
int temps_max;          /*temps d'analyse par coup*/
int prof;               /*profondeur de calcul en cours*/
int nb_coups;           /*nbre de coups joues*/
int fin_partie;         /*drapeau de fin de partie*/
int noeuds;             /*nbre de positions analysees*/
int sc;                 /*score ramene de alpha beta*/
int pr[8];              /*table des retournements pour le generateur de coups*/
int finale;             /*drapeau de fin parfaite*/
int infini;             /*val pour alpha beta*/
int passe[40];          /*drapeau passer son tour*/
int passe_adv;
int passe_prog;
int pas_de_coups[3];
int ouverture;
int tout_seul;

/*
structure pour enregistrer les coups
*/
typedef struct le_COUP
    {
        int ncj;          /*n°case jouee*/
        int prd[8];    /*nbre pions retournés dans chaque direction*/
        int tpr;       /*total pions retournes*/
    } COUP;

COUP  liste_coups_peres[30];

COUP pv[PROF_MAX][PROF_MAX];
int  pv_lenght[PROF_MAX];
    
/*
structure pour sauvegarder les coups de la partie et dans l'arbre
*/
typedef struct la_PARTIE
    {
        COUP c;            /*coup joue*/
    } PARTIE;
PARTIE       coups[80]; /*garder 80 1/2     coups , suffisant en tenant compte de quelques "passe"*/

/*
directions de retournement
*/
int d[8] = {10,11,1,-9,-10,-11,-1,9};

/*
pour la fonction aleatoire et gestion du temps
*/
int       ftime_ok = FAUX;  /* does ftime return milliseconds? */
time_t    nb_secondes, tp,sec;
int       in;
int       debut,fin;
int       temps;
int       fin_recherche;
jmp_buf   jump;

/*
globales pour la fonction d'evaluation
*/
int f[3];                 /*score de frontiere noir et blanc*/
int m[3];                 /*score de materiel noir et blanc*/
int vc[3];           /*score positionel noir et blanc*/
int score;

/*table pour calcul frontiere*/
int t[100]; 

/*table strategique des cases*/

int ts[100] = {
                0,0,0,0,0,0,0,0,0,0,
               0,200,3,18,24,24,18,3,200,0,
               0,3,-165,6,12,12,6,-165,3,0,
               0,18,6,30,30,30,30,6,18,0,
               0,24,12,30,0,0,30,12,24,0,
               0,24,12,30,0,0,30,12,24,0,
               0,18,6,30,30,30,30,6,18,0,
               0,3,-165,6,12,12,6,-165,3,0,
                0,200,3,18,24,24,18,3,200,0,
               0,0,0,0,0,0,0,0,0,0
              /* 0,0,0,0,0,0,0,0,0,0,
               0,200,1,6,8,8,6,1,200,0,
               0,1,-55,2,4,4,2,-55,1,0,
               0,6,2,10,10,10,10,2,6,0,
               0,8,4,10,0,0,10,4,8,0,
               0,8,4,10,0,0,10,4,8,0,
               0,6,2,10,10,10,10,2,6,0,
               0,1,-55,2,4,4,2,-55,1,0,
               0,200,1,6,8,8,6,1,200,0,
               0,0,0,0,0,0,0,0,0,0*/
               };
/*
versions pour le mode auto
*/
int no,bl;
int version[3];   
/*
ponderations frontiere et materiel version 1.0 (+modifs)
*/
int k1;
int k2;
int k3;

/*
ponderations autres versions
*/
int pav[5][4]= {
                0,0,0,0,
                0,1,1,1,
                0,3,1,1,
                0,5,1,1,
                0,7,1,1,
               };

/*
nombre de pions sur l'othellier
*/
int total_pions;

/*
hash tables
*/
int hash_cases[100][3];
int hash;
                        
void affiche_resultat()
{
  printf("----------PARTIE TERMINEE-----------\n");
  if(couleur_HPothelloC == NOIR)
    {
      if(m[NOIR] > m[BLANC])
        printf("HPotheloC gagne ---> %d - %d\n",m[NOIR],m[BLANC]);
      else if( m[BLANC] > m[NOIR])
        printf("HPotheloC perd ---> %d - %d\n",m[BLANC],m[NOIR]);
      else
        printf("Partie nulle\n"); 
    }
  else
    {
      if( m[BLANC] > m[NOIR])
        printf("HPotheloC gagne ---> %d - %d\n",m[BLANC],m[NOIR]);
      else if(m[NOIR] > m[BLANC])
        printf("HPotheloC perd ---> %d - %d\n",m[NOIR],m[BLANC]);
      else
        printf("Partie nulle\n"); 
    }
  printf("\n");  
}

void affiche_resultat_coup_joue()
{
}

void affiche_othellier()
{
  int     n = 0;
  int     i,j;
  
             
     for (i=81;i>=11;i-=10)
         {
         n++;
         printf("   +---+---+---+---+---+---+---+---+\n");
         printf("%d  |",n);
            for (j=i;j<=(i+7);j++)
              {              
                if (othellier[j] != VIDE)
                  {
                     if(othellier[j] == NOIR)
                       printf(" X |");
                     else
                       printf(" O |");       
                  }                                     
                 else
                   printf("   |");
                 }
                    
          printf("\n");
          }
 printf("   +---+---+---+---+---+---+---+---+\n");         
 printf("\n");
 printf("     A   B   C   D   E   F   G   H\n");
 printf("\n");
 printf("NOIR   : %d\n",m[NOIR]);
 printf("BLANC  : %d\n",m[BLANC]);
 
 printf("           -----------------\n");
 
 if (side == BLANC)
 printf("           |   BLANC JOUE  |\n");
 else
    printf("           |   NOIR JOUE   |\n");
    
    printf("           -----------------\n");
     
}


void affiche_liste_coups_joues()
{
   int i;
   
   for(i=0;i<=nb_coups;i++)
     printf("%s \n",coup_partie_str(i));  
}
