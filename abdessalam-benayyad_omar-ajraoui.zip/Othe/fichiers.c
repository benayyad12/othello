#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichiers.h"


#define BLANC    0
#define NOIR    1
#define VIDE    2
#define JOUABLE 3

#define PION_BLANC    "  X  "
#define PION_NOIR    "  O  "
#define PION_VIDE    "     "
#define PION_JOUABLE "  .  "

#define FAUX 0
#define VRAI  1
typedef struct Joueur
{
    char nom[40];
    int score;
}joueur;
joueur Joueur1;
joueur Joueur2;
void entrer_nom_joueur(void)
{
    char name[40];
    printf("Donner votre nom : \n");
    scanf("%s",name);
    strcpy(Joueur1.nom,name);
}
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*la fonction elementaire qui permet d'enregistrer les noms des joueurs */
void enregistrer_nom_joueur(void)
{
    int i;
    remove("partie_encours.txt");
    FILE *fichier=fopen("partie_encours2.txt","w");
    if(fichier==NULL)
    {
        exit(1);
    }
    fprintf(fichier,"%s\n",Joueur1.nom);
    fclose(fichier);
}
void entrer_noms_joueurs(void)
{
    char name[40];
    printf("Donner votre nom (joueur des pions Blancs (X) ) : \n");
    scanf("%s",name);
    strcpy(Joueur1.nom,name);
    printf("Donner votre nom (joueur des pions Noirs (O) ) : \n");
    scanf("%s",name);
    strcpy(Joueur2.nom,name);
}
void creer_fichier(void)
{   
    FILE *fichier=fopen("enregistrer_joueur.txt","w");
    if(fichier==NULL)
    {
        printf("EROORR");
        exit(1);
    }
    Joueur1.score=scores[NOIR];
    Joueur2.score=scores[BLANC];
    fprintf(fichier,"%s\n",Joueur1.nom);
    fprintf(fichier,"%s\n",Joueur2.nom);
    fprintf(fichier,"%s\n",Joueur1.score);
    fprintf(fichier,"%s\n",Joueur2.score);
    fclose(fichier);
}

/*fonction d'initialisation du jeu */
void init_jeu(void)
{
    memset( M, VIDE, sizeof( M ) );
    M[3][3] = NOIR;
    M[4][4] = NOIR;
    M[3][4] = BLANC;
    M[4][3] = BLANC;
    scores[BLANC] = 2;
    scores[NOIR] = 2;
    joueur_actuel = NOIR;
}
/* fonction qui retourne si une position est dedans l'othellier */
int position_valide( int i, int j )
{
    if ( i < 0 || i >= 8 || j < 0 || j >= 8 ) return FAUX;
    return VRAI;
}
/*fonction auxilliaire du calcul des distance entre deux pions en lignes et en colonnes */  
int distance( int i1, int j1, int i2, int j2 )
{
    int di = abs( i1 - i2 ), dj = abs( j1 - j2 );
    if ( di > 0 ) return di;
    return dj;
}
/* fonction qui retourne la validite d'un coup jouable */
int est_jouable( int i, int j )
{
    memset( dir_jouable[i][j], 0, 8 );
    if ( !position_valide( i, j ) ) return FAUX;
    if ( M[i][j] != VIDE ) return FAUX;
    int JETON_JOUABLE = FAUX;

    int joueur_adversaire = ( joueur_actuel + 1 ) % 2;

    // Test UL diagonal
    int i_it = i-1, j_it = j-1;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
    {
        i_it -= 1;
        j_it -= 1;
    }
    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][0] = 1;
        JETON_JOUABLE = VRAI;
    }

    // Test UP path
    i_it = i-1, j_it = j;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
        i_it -= 1;

    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][1] = 1;
        JETON_JOUABLE = VRAI;
    }

    // Test UR diagonal
    i_it = i-1, j_it = j+1;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
    {
        i_it -= 1;
        j_it += 1;
    }
    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][2] = 1;
        JETON_JOUABLE = VRAI;
    }

    // Test LEFT path
    i_it = i, j_it = j-1;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
        j_it -= 1;

    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][3] = 1;
        JETON_JOUABLE = VRAI;
    }

    // Test RIGHT path
    i_it = i, j_it = j+1;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
        j_it += 1;

    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][4] = 1;
        JETON_JOUABLE = VRAI;
    }

    // Test DL diagonal
    i_it = i+1, j_it = j-1;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
    {
        i_it += 1;
        j_it -= 1;
    }
    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][5] = 1;
        JETON_JOUABLE = VRAI;
    }

    // Test DOWN path
    i_it = i+1, j_it = j;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
        i_it += 1;

    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][6] = 1;
        JETON_JOUABLE = VRAI;
    }

    // Test DR diagonal
    i_it = i+1, j_it = j+1;
    while ( position_valide( i_it, j_it ) && M[i_it][j_it] == joueur_adversaire )
    {
        i_it += 1;
        j_it += 1;
    }
    if ( position_valide( i_it, j_it ) && distance( i, j, i_it, j_it ) > 1 && M[i_it][j_it] == joueur_actuel )
    {
        dir_jouable[i][j][7] = 1;
        JETON_JOUABLE = VRAI;
    }
    return JETON_JOUABLE;
}
/* fonction qui marque les posiotions jouables par un point "." */
void marquer_position_jouable( )  //marquer_position_jouable
{
    coup_legal = FAUX;
    for ( int i=0; i<8; ++i )
    {
        for ( int j=0; j<8; ++j )
        {
            if ( M[i][j] == JOUABLE )
                M[i][j] = VIDE;
            if ( est_jouable( i, j ) )
            {
                M[i][j] = JOUABLE;
                coup_legal = VRAI;
            }
        }
    }
}
/* fonction d'affichage d'othellier */
void dessiner_othellier( )
{
    printf( "     %c     %c     %c     %c     %c     %c     %c     %c\n", nom_colonne[0], nom_colonne[1], nom_colonne[2], nom_colonne[3], nom_colonne[4], nom_colonne[5], nom_colonne[6], nom_colonne[7] );
    printf( "   _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n" );
    for ( int i=0; i<8; ++i )
    {
        printf( "  |     |     |     |     |     |     |     |     |\n" );
        printf( "%c |", nom_ligne[i] );
        for ( int j=0; j<8; ++j )
        {
            if ( M[i][j] == BLANC )
            {
                printf( "%s", PION_BLANC );
            } else if ( M[i][j] == NOIR )
            {
                printf( "%s", PION_NOIR );
            } else if ( M[i][j] == JOUABLE )
            {
                printf( "%s", PION_JOUABLE );
            } else
            {
                printf( "%s", PION_VIDE );
            }
            printf("|");
        }
        printf( "\n" );
        printf( "   _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n" );
    }
    printf( "\n" );
}
/* fonction qui verifie si un coup est valide */
void afficher_mvmt_illegal( )
{
    if ( coup_illegal )
    {
        printf( "tu as entrer un mouvement qui n'est pas valide!\n" );
        coup_illegal = FAUX;
    }
}
/* fonction d'affichage du joueur suivant */
void afficher_joueur_actuel( )
{
    printf( "le joueur actuel:" );
    if ( joueur_actuel == BLANC )
        printf( "%s", PION_BLANC );
    else
        printf( "%s", PION_NOIR );
    printf( "\n" );
}
/* fonction d'inversement du joueur */
void change_joueur_actuel( )
{
    joueur_actuel = ( joueur_actuel + 1 ) % 2;
}

/* fonction qui lit le coup entre */
void mvmt_rapide( int *p_ligne, int *p_colonne )
{    
    printf( "Entrer une ligne et colonne separer par une seule espace (exemple!.: 2 4).\n" );
    scanf( "%d %d", p_ligne, p_colonne );
}
void mvt_machine(int *p_ligne , int *p_colonne)
{      srand(time(0)) ;
      *p_ligne=rand() %9;
      *p_colonne=rand() %9;

}
/* fonction qui capture des pions de l'adversaire */
void capturer_pions( int i, int j )
{
    int joueur_adversaire = ( joueur_actuel + 1 ) % 2;
    int i_it, j_it;

    // Capture UL diagonal
    if ( dir_jouable[i][j][0] )
    {
        i_it = i-1, j_it = j-1;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            i_it -= 1;
            j_it -= 1;
        }
    }

    // Capture UP path
    if ( dir_jouable[i][j][1] )
    {
        i_it = i-1, j_it = j;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            i_it -= 1;
        }
    }

    // Capture UR diagonal
    if ( dir_jouable[i][j][2] )
    {
        i_it = i-1, j_it = j+1;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            i_it -= 1;
            j_it += 1;
        }
    }

    // Capture LEFT path
    if ( dir_jouable[i][j][3] )
    {
        i_it = i, j_it = j-1;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            j_it -= 1;
        }
    }

    // Capture RIGHT path
    if ( dir_jouable[i][j][4] )
    {
        i_it = i, j_it = j+1;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            j_it += 1;
        }
    }

    // Capture DL diagonal
    if ( dir_jouable[i][j][5] )
    {
        i_it = i+1, j_it = j-1;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            i_it += 1;
            j_it -= 1;
        }
    }

    // Capture DOWN path
    if ( dir_jouable[i][j][6] )
    {
        i_it = i+1, j_it = j;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            i_it += 1;
        }
    }

    // Capture DR diagonal
    if ( dir_jouable[i][j][7] )
    {
        i_it = i+1, j_it = j+1;
        while ( M[i_it][j_it] == joueur_adversaire )
        {
            M[i_it][j_it] = joueur_actuel;
            scores[joueur_actuel]++;
            scores[joueur_adversaire]--;
            i_it += 1;
            j_it += 1;
        }
    }
}
/* fonction qui effectue un coup */ 
void faire_mvmt_suivant( )
{
    int ligne, colonne;
    mvmt_rapide( &ligne, &colonne );
    if ( position_valide( ligne, colonne ) && M[ligne][colonne] == JOUABLE )
    {
        M[ligne][colonne] = joueur_actuel;
        scores[joueur_actuel]++;
        capturer_pions( ligne, colonne );
        change_joueur_actuel(  );
    }
    else coup_illegal = VRAI;
}
void faire_mvmt_suivant_M()
{
    int ligne, colonne;
    mvt_machine( &ligne, &colonne );
    if ( position_valide( ligne, colonne ) && M[ligne][colonne] == JOUABLE )
    {
        M[ligne][colonne] = joueur_actuel;
        scores[joueur_actuel]++;
        capturer_pions( ligne, colonne );
        change_joueur_actuel(  );
    }
    else coup_illegal = VRAI;
    
}
/* fonction d'affichage du gagnant */
void afficher_gagnant( )
{
    printf( "le score final:\n%s: %d %s: %d\n", PION_BLANC, scores[BLANC], PION_NOIR, scores[NOIR] );
    if ( scores[BLANC] > scores[NOIR] )
        printf( "%s gagne.\n", PION_BLANC );
    else if ( scores[BLANC] < scores[NOIR] )
        printf( "%s gagne.\n", PION_NOIR );
    else
        printf( "egalisation.\n" );
}
/* fonction d'affichage du score */
void afficher_score( )
{ 
    printf( "%s: %d %s: %d\n", PION_BLANC, scores[BLANC], PION_NOIR, scores[NOIR] );
}
void Lire_trier_affi_scores(void)
{
    char name[40];
    int score;
    char temp_char; // un charactere temporaire pour calculer le nombre des lignes dans le fichier
    int n=0,i,j;
    FILE *fichier=fopen("Meilleures_scores2.txt","r");
    if(fichier==NULL)
        exit(1);
    while(1)
    {   
        temp_char=fgetc(fichier);
        if(temp_char=='\n')    // incrementer le n si un saut de ligne est rencontre
            n++;
        if(feof(fichier))
            break; 
    }                       
    joueur liste_scores[n];
    rewind(fichier);   // Reinitialisation du curseur
    n=0;
    while(!feof(fichier))
    {
        fscanf(fichier,"%s %d",liste_scores[n].nom,&(liste_scores[n].score));
        n++;
    }
    /* on commence par trier les pointeurs par les scores associes */
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
        {
            if(liste_scores[i].score < liste_scores[j].score)  /* le tri s'effectue en decroissance */
            {
                char temp_char[40];
                int temp_int;
                temp_int=liste_scores[i].score;                             /* on utilise un tri par selection */
                liste_scores[i].score=liste_scores[j].score;
                liste_scores[j].score=temp_int;
                strcpy(temp_char,liste_scores[i].nom);
                strcpy(liste_scores[i].nom,liste_scores[j].nom);
                strcpy(liste_scores[j].nom,temp_char);
            }
        }    
    printf("Les meilleures scores sont :\n");
    if(n-1<9)                                 // toujours une ligne est ajoutee lors de comptage donc on restreint une
    {                                         // cette didjonction des cas est due a une eventuelle incmpletude de dix scores dans le fichier
        for(i=0;i<n-1;i++)                                  
        {
            printf("%s %d \n",liste_scores[i].nom,liste_scores[i].score);
        }
    }
    else {
    for(i=0;i<10;i++)
        printf("%s %d \n",liste_scores[i].nom,liste_scores[i].score);}
    fclose(fichier);
    
}