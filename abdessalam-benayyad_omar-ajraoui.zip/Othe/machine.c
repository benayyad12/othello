
#define _Othello_
#define BLANC    0
#define NOIR    1
#define VIDE    2
#define JOUABLE 3

#define PION_BLANC    "  X  "
#define PION_NOIR    "  O  "
#define PION_VIDE    "     "
#define PION_JOUABLE "  .  "

#define FAUX 0
#define VRAI  1

const char *nom_ligne = "01234567";
const char *nom_colonne = "01234567";

char M[8][8]; /* Matrice 8x8 */
int dir_jouable[8][8][8]; // direction jouable
int joueur_actuel;
int jeu_fini = FAUX;
int passer_tourne = FAUX;
int coup_illegal = FAUX;
int coup_legal = FAUX;
int scores[2];
int score_noir = 2;
 
 void jeux(void)
 {
     while ( !jeu_fini ){
        if ( !coup_illegal ) marquer_position_jouable( );
        if ( !coup_legal )
        {
            if ( passer_tourne )
            {
                jeu_fini = 1;
                dessiner_othellier( );
                continue;
            }
            passer_tourne = 1;
            change_joueur_actuel( );
            continue;
        }
        passer_tourne = 0;
        dessiner_othellier( );
        afficher_score( );
        afficher_joueur_actuel( );
        afficher_mvmt_illegal( );
        faire_mvmt_suivant( );
    } 
 }

void faire_mvmt_suivant_M( )
{
    int ligne, colonne;
    mvmt_machine( &ligne, &colonne );
    if ( position_valide( ligne, colonne ) && M[ligne][colonne] == JOUABLE )
    {
        M[ligne][colonne] = joueur_actuel;
        scores[joueur_actuel]++;
        capturer_pions( ligne, colonne );
        change_joueur_actuel(  );
    }
    else coup_illegal = VRAI;
}

  