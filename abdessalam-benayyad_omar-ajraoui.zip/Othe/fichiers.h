#ifndef _Othello_
#define _Othello_
#define BLANC    0
#define NOIR    1
#define VIDE    2
#define JOUABLE 3

#define PION_BLANC    "  X  "
#define PION_NOIR    "  O  "
#define PION_VIDE    "     "
#define PION_JOUABLE "  .  "

#define FAUX 0
#define VRAI  1

const char *nom_ligne = "01234567";
const char *nom_colonne = "01234567";

char M[8][8]; /* Matrice 8x8 */
int dir_jouable[8][8][8]; // direction jouable
int joueur_actuel;
int jeu_fini = FAUX;
int passer_tourne = FAUX;
int coup_illegal = FAUX;
int coup_legal = FAUX;
int scores[2];
int score_noir = 2;



/*Prototypes des fonctions */
void init_jeu(void);
int position_valide( int i, int j );
int est_jouable( int i, int j );
void marquer_position_jouable( );
void dessiner_othellier( );
void afficher_mvmt_illegal( );
void afficher_joueur_actuel( );
void change_joueur_actuel( );
void mvmt_rapide( int *p_ligne, int *p_colonne );
void capturer_pions( int i, int j );
void faire_mvmt_suivant( );
void afficher_gagnant( );
void afficher_score( );
void Lire_trier_affi_scores();
void jeuxvsmachine();
void jeux();






#endif