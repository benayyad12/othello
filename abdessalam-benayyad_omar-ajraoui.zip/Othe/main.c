#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fichiers.h"
#include "fichiers.c"


int main(void)
{   int a;
            
    printf("\n ______JOUER CONTRE HUMAIN_______\n");
    printf("\n ______JOUER CONTRE MACHINE______\n");
    printf("CHOIX :  \n 1[joueur] \n 0[machine] ");
    scanf("%d",&a);
    if (a==1)
    {
    entrer_noms_joueurs();
    creer_fichier();
    init_jeu();
    while ( !jeu_fini ){
        if ( !coup_illegal ) marquer_position_jouable( );
        if ( !coup_legal )
        {
            if ( passer_tourne )
            {
                jeu_fini = 1;
                dessiner_othellier( );
                continue;
            }
            passer_tourne = 1;
            change_joueur_actuel( );
            continue;
        }
        passer_tourne = 0;
        dessiner_othellier( );
        afficher_score( );
        afficher_joueur_actuel( );
        afficher_mvmt_illegal( );
        faire_mvmt_suivant( );
    } }
    else if (a==0)
    {
          entrer_nom_joueur();
          enregistrer_nom_joueur();
          init_jeu(); 
           while ( !jeu_fini ){
        if ( !coup_illegal ) marquer_position_jouable( );
        if ( !coup_legal )
        {
            if ( passer_tourne )
            {
                jeu_fini = 1;
                dessiner_othellier( );
                continue;
            }
            passer_tourne = 1;
            change_joueur_actuel( );
            continue;
        }
        passer_tourne = 0;
        dessiner_othellier( );
        afficher_score( );
        afficher_joueur_actuel( );
        afficher_mvmt_illegal( );
        if (joueur_actuel==0)
        {
            faire_mvmt_suivant( );
        } 
        
        else if (joueur_actuel==1)
        {
            faire_mvmt_suivant_M( );
        }
        
       }
      }
        afficher_gagnant( );
        Lire_trier_affi_scores();
    return 0; 
}